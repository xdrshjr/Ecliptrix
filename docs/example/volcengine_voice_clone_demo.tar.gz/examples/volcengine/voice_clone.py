#!/usr/bin/python
# -*- coding: utf-8 -*-
import argparse
import base64
import logging
import os
import uuid

import requests

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main() -> None:
    parser = argparse.ArgumentParser(description="Voice clone API v3 demo")
    parser.add_argument("--appid", required=True, help="APP ID")
    parser.add_argument("--access_token", required=True, help="Access Token")
    parser.add_argument("--speaker_id", default="", help="Speaker ID")
    parser.add_argument("--file_path", default="", help="Audio file path")
    parser.add_argument("--language", type=int, default=0, help="Language enum")
    args = parser.parse_args()

    request_id = str(uuid.uuid4())
    headers = {
        "Content-Type": "application/json",
        "X-Api-App-Key": str(args.appid),
        "X-Api-Access-Key": str(args.access_token),
        "X-Api-Request-Id": request_id,
    }

    with open(args.file_path, "rb") as f:
        audio_bytes = f.read()
    audio_format = os.path.splitext(args.file_path)[1].lstrip(".").lower() or "wav"

    body: dict = {
        "speaker_id": args.speaker_id,
        "audio": {
            "data": base64.b64encode(audio_bytes).decode("utf-8"),
            "format": audio_format,
        },
        "language": args.language,
        "extra_params": {
            "voice_clone_denoise_model_id": "",
        },
    }

    url = "https://openspeech.bytedance.com/api/v3/tts/voice_clone"
    resp = requests.post(url, headers=headers, json=body, timeout=30)

    logid = resp.headers.get("X-Tt-Logid", "")
    print(logid)

    resp.raise_for_status()
    print(resp.json())


if __name__ == "__main__":
    main()
